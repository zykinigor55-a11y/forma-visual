# PLUX V10.2 — video and glass fixes

- Removed browser `HEAD` preflight before starting MP4. Browser fetches the media itself with native playback controls and logs decoder errors in the console.
- MP4 playback uses `muted`, `playsinline`, `autoplay`, `loop`; fallback remains until the browser emits `playing`. `visibilitychange` replays video after switching back to the tab.
- Node server supports HTTP `Range: bytes=...`, responds `206 Partial Content` with `Content-Range`, `Accept-Ranges: bytes`. This is important for Safari mobile video playback.
- A new translucent green crystal material for bottom navigation, chosen tab and voice capsule; brighter edges, more restrained opaque gradients and stronger microphone-like glow on active tab.
- Increased feather masking and removed element isolation around character/video to make hard dark backdrop less visible.

**Limit:** Since original MP4 frames include a dark background and no alpha channel, CSS blending can reduce but not *guarantee* complete removal of every possible seam. Fully seamless integration requires rendering videos with alpha (supported format) or exporting the mascot and environment together as one composition. Keep original raw videos for this.

Online deployment is not performed by this ZIP. Open by running `npm start` from the project folder on a web server or deploy public assets to a static HTTPS host. A standalone local HTML file with `/assets/...` absolute paths is not equivalent to running the app.
