import {test} from 'node:test';
import {strict as assert} from 'node:assert';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
const read=(file)=>readFileSync(join(process.cwd(),'public',file),'utf8');

test('main navigation is a live CSS glass dock rather than a fixed preselected image',()=>{
  const css=read('crystal-v10.css');
  assert.match(css,/\.screen-home \.bottom-nav\s*\{/);
  assert.match(css,/\.screen-home \.bottom-nav \.nav-button\.selected\s*\{/);
  assert.match(css,/background-image:\s*radial-gradient\(/);
  assert.doesNotMatch(css.slice(css.indexOf('/* V10.1')),/background[^\n]*nav-shell\.png[^\n]*!important/);
  assert.match(read('app.js'),/el\.setAttribute\('aria-current','page'\)/);
});

test('video autoplay is real media, with fallback only until playback starts',()=>{
  const js=read('app.js');
  const css=read('crystal-v10.css');
  assert.match(js,/videoSpeeds=\{idle:1\.5,listening:1\.5,thinking:1\.5,talking:1\.5,happy:1\.5\}/);
  assert.match(js,/v\.onplaying=\(\)=>\{if\(fresh\(\)\)el\.classList\.add\('has-video','video-ready'\)\}/);
  assert.match(js,/v\.playsInline=true;v\.autoplay=true/);
  assert.doesNotMatch(js,/fetch\(path,\{method:'HEAD'\}\)/);
  assert.match(css,/\.scene-home \.mascot-hit>img,\s*\.scene-home \.mascot-hit>video/);
  assert.match(css,/ellipse 49% 49%/);
  assert.match(css,/\.screen-home \.speech-glass::after/);
});
