import test from 'node:test';
import assert from 'node:assert/strict';
const played=[];
let handler;
const store=new Map();
globalThis.localStorage={getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)};
globalThis.document={hidden:false,addEventListener:(name,fn)=>{if(name==='click')handler=fn}};
globalThis.Audio=class {
  constructor(src){this.src=src;this.preload='';this.volume=1}
  cloneNode(){return new globalThis.Audio(this.src)}
  play(){played.push({src:this.src,volume:this.volume});return Promise.resolve()}
};
const m=await import('../public/sfx.js?test=1');
test('valid sounds play once, at low levels',()=>{
  const result=m.playSfx('success');
  assert.equal(result,true);
  assert.equal(played.length,1);
  assert.match(played[0].src,/success\.wav$/);
  assert.equal(played[0].volume,.27);
  assert.equal(m.playSfx('nonexistent'),false);
});
test('off persists and suppresses sounds',()=>{
  m.setSoundEnabled(false);
  assert.equal(store.get('plux_sfx_enabled'),'off');
  assert.equal(m.playSfx('bubble'),false);
  assert.equal(played.length,1);
  m.setSoundEnabled(true);
  assert.equal(store.get('plux_sfx_enabled'),'on');
});
test('navigation choices select intended sounds',()=>{
  m.installInterfaceSfx();
  const emit=(id,value='')=>handler({target:{closest:()=>({id,classList:{contains:()=>false},dataset:{}})}});
  emit('home-mascot');emit('open-notifications');
  assert.match(played.at(-2).src,/happy\.wav$/);
  assert.match(played.at(-1).src,/notification\.wav$/);
});
