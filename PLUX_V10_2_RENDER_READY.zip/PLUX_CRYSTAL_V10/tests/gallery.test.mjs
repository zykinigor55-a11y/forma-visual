import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const root = new URL('../public/', import.meta.url);
const read = name => readFileSync(new URL(name, root), 'utf8');

test('create gallery has three depth layers, live art, and intact create form', () => {
  const html = read('index.html');
  assert.match(html, /id="create-gallery"/);
  assert.match(html, /class="poster-side left"/);
  assert.match(html, /class="poster-side right"/);
  assert.match(html, /class="featured-art"/);
  assert.match(html, /id="image-prompt"/);
  assert.match(html, /id="create-art-button"/);
  assert.match(html, /gallery-motion\.css/);
  assert.match(html, /gallery-motion\.js/);
});

test('gallery motion includes subtle three-layer movement and reduced-motion mode', () => {
  const css = read('gallery-motion.css');
  assert.match(css, /@keyframes plux-card-center/);
  assert.match(css, /@keyframes plux-card-left/);
  assert.match(css, /@keyframes plux-card-right/);
  assert.match(css, /prefers-reduced-motion: reduce/);
  assert.match(css, /transform-style: preserve-3d/);
});
