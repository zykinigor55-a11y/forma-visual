import { createServer } from 'node:http';
import { createReadStream, statSync } from 'node:fs';
import { resolve, extname, sep } from 'node:path';
import { timingSafeEqual, createHash } from 'node:crypto';

const ROOT = resolve('public');
const AGENT_ID = process.env.ELEVENLABS_AGENT_ID || 'agent_7501m6wt1wm5efybwty352yqned2';
const PORT = Number(process.env.PORT || 8080);
const TYPES = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.jpg':'image/jpeg','.png':'image/png','.webp':'image/webp','.mp4':'video/mp4','.wav':'audio/wav','.svg':'image/svg+xml'};
const attempts = new Map();
const hash=(s)=>createHash('sha256').update(s).digest();
const verify=(a,b)=> typeof a==='string'&&typeof b==='string'&&timingSafeEqual(hash(a), hash(b));
function json(res,code,obj){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(obj));}
export function handler(req,res,{upstream=fetch,env=process.env}={}){
 res.setHeader('X-Content-Type-Options','nosniff');
 res.setHeader('Referrer-Policy','no-referrer');
 res.setHeader('Permissions-Policy','microphone=(self)');
 res.setHeader('Content-Security-Policy',"default-src 'self'; connect-src 'self' wss://api.elevenlabs.io; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; object-src 'none'; base-uri 'self'");
 const url=new URL(req.url||'/', 'http://localhost');
 if(url.pathname==='/api/health')return json(res,200,{ready:!!(env.ELEVENLABS_API_KEY && env.PLUH_DEMO_CODE),agentConfigured:!!AGENT_ID,service:'PLUH demo'});
 if(url.pathname==='/api/session'){
   if(req.method!=='POST')return json(res,405,{error:'Method not allowed'});
   if(!env.ELEVENLABS_API_KEY || !env.PLUH_DEMO_CODE)return json(res,503,{error:'Сервер пока не настроен. Нужны ELEVENLABS_API_KEY и PLUH_DEMO_CODE в Render.'});
   const ip=String(req.headers['x-forwarded-for']||req.socket?.remoteAddress||'unknown').split(',')[0];
   const now=Date.now(); const recent=(attempts.get(ip)||[]).filter(t=>now-t<60_000);
   if(recent.length>=10)return json(res,429,{error:'Слишком много попыток. Попробуй позже.'});
   recent.push(now);attempts.set(ip,recent);
   let raw=''; req.on('data',c=>{raw+=c;if(raw.length>1024)req.destroy();});
   req.on('end',async()=>{
     let code='';try{code=JSON.parse(raw).code||'';}catch{}
     if(!verify(code, env.PLUH_DEMO_CODE))return json(res,401,{error:'Неверный код доступа к тесту.'});
     try{
       const uri=new URL('https://api.elevenlabs.io/v1/convai/conversation/get-signed-url');uri.searchParams.set('agent_id',env.ELEVENLABS_AGENT_ID||AGENT_ID);
       const r=await upstream(uri,{headers:{'xi-api-key':env.ELEVENLABS_API_KEY},signal:AbortSignal.timeout(12000)});
       if(!r.ok)return json(res,502,{error:`ElevenLabs отклонил запрос (HTTP ${r.status}). Проверь ключ и права доступа.`});
       const data=await r.json();
       if(typeof data.signed_url!=='string'||!data.signed_url.startsWith('wss://api.elevenlabs.io/'))return json(res,502,{error:'ElevenLabs вернул неожиданный ответ.'});
       return json(res,200,{signedUrl:data.signed_url});
     }catch(e){return json(res,502,{error:'Не удалось связаться с ElevenLabs. Проверь доступность API.'});}
   });
   return;
 }
 if(req.method!=='GET'&&req.method!=='HEAD')return json(res,405,{error:'Method not allowed'});
 let pathname;
 try{pathname=decodeURIComponent(url.pathname);}catch{return json(res,400,{error:'Bad path'});}
 if(pathname==='/')pathname='/index.html';
 const p=resolve(ROOT, '.'+pathname);
 if(!p.startsWith(ROOT+sep))return json(res,403,{error:'Forbidden'});
 try{
  const st=statSync(p);if(!st.isFile())throw Error('not file');
  const headers={'Content-Type':TYPES[extname(p)]||'application/octet-stream','Cache-Control':(['.html','.js','.css'].includes(extname(p))?'no-store':'public, max-age=86400'),'Accept-Ranges':'bytes'};
  const range=typeof req.headers.range==='string'?req.headers.range:'';
  let start=0,end=st.size-1,status=200;
  if(range){
    const match=/^bytes=(\d*)-(\d*)$/.exec(range);
    if(!match||(!match[1]&&!match[2])){res.writeHead(416,{...headers,'Content-Range':`bytes */${st.size}`});return res.end()}
    if(match[1]){start=Number(match[1]);if(match[2])end=Math.min(Number(match[2]),st.size-1)}
    else{start=Math.max(0,st.size-Number(match[2]))}
    if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start> end||start>=st.size){res.writeHead(416,{...headers,'Content-Range':`bytes */${st.size}`});return res.end()}
    status=206;headers['Content-Range']=`bytes ${start}-${end}/${st.size}`;
  }
  headers['Content-Length']=Math.max(0,end-start+1);
  res.writeHead(status,headers);
  if(req.method==='HEAD')return res.end();
  createReadStream(p,{start,end}).pipe(res);
 }catch{return json(res,404,{error:'Not found'});}
}
if(process.argv[1]&&resolve(process.argv[1])===new URL(import.meta.url).pathname){
 createServer(handler).listen(PORT,'0.0.0.0',()=>console.log(`PLUH web listening on ${PORT}; API key ${process.env.ELEVENLABS_API_KEY?'configured':'MISSING'}; demo code ${process.env.PLUH_DEMO_CODE?'configured':'MISSING'}`));
}
