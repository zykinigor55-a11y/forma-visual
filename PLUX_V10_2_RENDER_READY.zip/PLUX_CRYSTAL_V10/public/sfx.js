/* PLUX Liquid Glass Micro-SFX. Original audio, 0.10-0.41 seconds.
   All sounds require a user gesture; no ambient soundtrack or looping. */
const ROOT='/assets/sounds/';
const NAMES=['tap','bubble','open','close','listen','send','success','notification','happy','error'];
const ready=new Map();
const last=new Map();
let enabled=true;
try{enabled=localStorage.getItem('plux_sfx_enabled')!=='off'}catch{}
for(const n of NAMES){
  const audio=new Audio(ROOT+n+'.wav');
  audio.preload='auto';
  ready.set(n,audio);
}
export function isSoundEnabled(){return enabled}
export function setSoundEnabled(on){enabled=Boolean(on);try{localStorage.setItem('plux_sfx_enabled',enabled?'on':'off')}catch{}return enabled}
export function playSfx(name='tap',gain=1){
  if(!enabled||document.hidden||!ready.has(name))return false;
  const now=performance.now();
  if(last.has(name)&&now-last.get(name)<95)return false;
  last.set(name,now);
  try{
    const audio=ready.get(name).cloneNode();
    audio.volume=Math.min(1,Math.max(0,.27*gain));
    audio.play().catch(()=>{}); // Safari may require a direct touch; never crash UI.
    return true;
  }catch{return false}
}
export function installInterfaceSfx(){
  document.addEventListener('click',event=>{
    const button=event.target?.closest?.('button');
    if(!button||!enabled||button.id==='sound-preview')return;
    let name='tap';
    const id=button.id;
    if(id==='home-mascot')name='happy';
    else if(id==='open-notifications')name='notification';
    else if(id==='open-voice-quick'||id==='speech-button')name='listen';
    else if(id==='voice-toggle')name=button.classList.contains('live')?'close':'listen';
    else if(id==='voice-end'||id==='voice-back'||id==='chat-back'||id==='prefs-close'||id==='feature-close'||id==='feature-done')name='close';
    else if(id==='continue-onboard')name=document.getElementById('user-name')?.value.trim()?'success':'error';
    else if(id==='create-art-button')name=document.getElementById('image-prompt')?.value.trim()?'open':'error';
    else if(id==='prefs-save')name='success';
    else if(button.classList.contains('mode-card')||button.dataset.go==='create'||button.dataset.go==='modes')name='open';
    playSfx(name);
  },{capture:true,passive:true});
}
