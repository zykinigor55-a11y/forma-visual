/* Motion-only feature: interaction is progressive enhancement, never required for creating art. */
const gallery = document.querySelector('#create-gallery');
const stage = gallery?.querySelector('.gallery-stage');
if (gallery && stage) {
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const reset = () => {
    stage.style.setProperty('--gallery-pointer-x', '0deg');
    stage.style.setProperty('--gallery-pointer-y', '0deg');
  };
  let running = false, last = null;
  gallery.addEventListener('pointermove', (event) => {
    if (reduced.matches || (event.pointerType === 'touch' && event.buttons !== 1)) return;
    const rect = gallery.getBoundingClientRect();
    last = {
      x: Math.max(-1, Math.min(1, (event.clientX - rect.left - rect.width/2) / (rect.width/2))),
      y: Math.max(-1, Math.min(1, (event.clientY - rect.top - rect.height/2) / (rect.height/2)))
    };
    if (running) return;
    running = true;
    requestAnimationFrame(() => {
      if (last) {
        stage.style.setProperty('--gallery-pointer-x', (last.x * 3.2).toFixed(2) + 'deg');
        stage.style.setProperty('--gallery-pointer-y', (-last.y * 2.5).toFixed(2) + 'deg');
      }
      running = false;
    });
  }, {passive:true});
  gallery.addEventListener('pointerleave', reset, {passive:true});
  gallery.addEventListener('pointerup', reset, {passive:true});
  gallery.addEventListener('pointercancel', reset, {passive:true});
  gallery.addEventListener('click', () => {
    if (reduced.matches) return;
    gallery.classList.remove('gallery-react');
    void gallery.offsetWidth;
    gallery.classList.add('gallery-react');
    window.setTimeout(() => gallery.classList.remove('gallery-react'), 620);
  });
  document.querySelectorAll('#screen-create [data-style]').forEach(button => {
    button.addEventListener('click', () => {
      if (reduced.matches) return;
      gallery.classList.remove('gallery-react');
      void gallery.offsetWidth;
      gallery.classList.add('gallery-react');
      window.setTimeout(() => gallery.classList.remove('gallery-react'), 620);
    });
  });
}
