/* Browser live sampler of the same PLUX liquid-glass micro-sound vocabulary.
   Preview uses original synthesized tones, rather than external audio samples. */
let ctx=null;
let gainLevel=.28;
const actions={
 tap:{name:'Стеклянное касание',desc:'0,10 сек',icon:'◈'},
 bubble:{name:'Живой пузырёк',desc:'0,22 сек',icon:'◌'},
 open:{name:'Открытие раздела',desc:'0,24 сек',icon:'↗'},
 close:{name:'Закрытие',desc:'0,18 сек',icon:'↙'},
 listen:{name:'PLUX слушает',desc:'0,29 сек',icon:'◉'},
 send:{name:'Отправка сообщения',desc:'0,17 сек',icon:'➤'},
 success:{name:'Успешное действие',desc:'0,41 сек',icon:'✦'},
 notification:{name:'Уведомление',desc:'0,33 сек',icon:'◇'},
 happy:{name:'PLUX радуется',desc:'0,33 сек',icon:'✳'},
 error:{name:'Мягкая ошибка',desc:'0,26 сек',icon:'−'}
};
const list=document.getElementById('sound-list');
for(const [id,item] of Object.entries(actions)){
 const b=document.createElement('button');b.type='button';b.className='sfx';b.dataset.sound=id;b.innerHTML=`<span class="glyph">${item.icon}</span><span class="names"><b>${item.name}</b><small>${item.desc}</small></span><span class="play">▶</span>`;
 b.addEventListener('click',()=>{play(id);document.querySelectorAll('.sfx').forEach(x=>x.classList.toggle('active',x===b));setTimeout(()=>b.classList.remove('active'),430)});
 list.append(b);
}
const v=document.getElementById('volume');v.addEventListener('input',()=>{gainLevel=Number(v.value)/100;document.getElementById('volume-label').textContent=v.value+'%'});
function osc(time,start,end,dur,amp=.4,type='sine'){
 const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.setValueAtTime(start,time);o.frequency.exponentialRampToValueAtTime(Math.max(30,end),time+Math.max(.03,dur));g.gain.setValueAtTime(.0001,time);g.gain.exponentialRampToValueAtTime(amp*gainLevel+0.0001,time+.006);g.gain.exponentialRampToValueAtTime(.0001,time+dur);o.connect(g).connect(ctx.destination);o.start(time);o.stop(time+dur+.008);
}
function play(id){
 try{
  if(!ctx)ctx=new (window.AudioContext||window.webkitAudioContext)();
  ctx.resume().catch(()=>{});
  const t=ctx.currentTime+.012;
  const tone=(dt,f1,f2,dur,a)=>osc(t+dt,f1,f2,dur,a);
  switch(id){
   case 'tap':tone(0,760,480,.085,.20);tone(.006,1600,1500,.034,.07);break;
   case 'bubble':tone(0,650,370,.145,.25);tone(.075,1040,630,.095,.13);break;
   case 'open':tone(0,380,770,.20,.16);tone(.11,790,790,.12,.08);break;
   case 'close':tone(0,640,330,.16,.15);break;
   case 'listen':tone(0,570,760,.22,.17);tone(.089,1020,1020,.15,.11);break;
   case 'send':tone(0,890,600,.12,.18);tone(.053,1180,1180,.075,.12);break;
   case 'success':tone(0,660,660,.24,.15);tone(.084,880,880,.24,.16);tone(.17,1320,1320,.22,.15);break;
   case 'notification':tone(0,960,960,.21,.16);tone(.112,1210,1210,.18,.13);break;
   case 'happy':tone(0,540,390,.13,.17);tone(.078,800,500,.15,.21);tone(.135,1300,1300,.17,.08);break;
   case 'error':tone(0,510,370,.20,.12);tone(.075,430,290,.15,.07);break;
  }
 }catch(e){console.info('Audio not supported in this browser',e)}
}
