Place muted 9:16 MP4s from Kling here using the following exact names:
01_idle.mp4
02_listening.mp4
03_thinking.mp4
04_talking.mp4
05_happy.mp4
06_notification.mp4
07_success.mp4
08_welcome.mp4
09_surprised.mp4
10_affection.mp4
11_focus.mp4
12_peek_phone.mp4
13_photo_generation.mp4
The frontend automatically switches to the matching video when available.
